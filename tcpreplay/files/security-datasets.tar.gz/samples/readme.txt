Thanks to OpenPacket.org for these pcaps!

They were downloaded on 2012/12/02 from:
https://www.openpacket.org/capture/list

Individual links:

10k.pcap 
https://www.openpacket.org/capture/show/66

4in6.pcap 
https://www.openpacket.org/capture/show/73

6to4.pcap 
https://www.openpacket.org/capture/show/74

best_malware_protection.pcap 
https://www.openpacket.org/capture/show/79

bredolab-sample.pcap 
https://www.openpacket.org/capture/show/70

ConfickerB9hrs.pcap 
https://www.openpacket.org/capture/show/52

emerging-all.pcap 
https://www.openpacket.org/capture/show/63

evidence03.pcap 
https://www.openpacket.org/capture/show/65

example.com-1.pcap 
https://www.openpacket.org/capture/show/53

example.com-3.pcap 
https://www.openpacket.org/capture/show/54

example.com-4.pcap 
https://www.openpacket.org/capture/show/55

example.com-5.pcap 
https://www.openpacket.org/capture/show/56

example.com-6.pcap 
https://www.openpacket.org/capture/show/57

example.com-7.pcap 
https://www.openpacket.org/capture/show/58

fake_av.pcap 
https://www.openpacket.org/capture/show/78

ip-fragment-attack.pcap 
https://www.openpacket.org/capture/show/71

zeus-sample-1.pcap 
https://www.openpacket.org/capture/show/67

zeus-sample-2.pcap 
https://www.openpacket.org/capture/show/68

zeus-sample-3.pcap 
https://www.openpacket.org/capture/show/69

