exploit.pcap came from https://github.com/broala/bro-shellshock
